#include <iostream>

int main() {
    int n,i;
    int posicion;
    printf("INgrese la cantidad de elementos:\n");
    scanf("%d",&n);

int datos[n];

    //obtener datos
    for(i=0;i<n;i++){
        printf("Numero - %d : ",i+1);
        scanf("%d",&datos[i]);
        printf("\n");
    }
//mostrar datos
    printf("El array :\n");
    for(i=0;i<n;i++){
        printf("%5d",datos[i]);
    }
    printf("\n\n");

    //buscar posicion
    printf("ingrese la posicion a eliminar: \n");
    scanf("%d",&posicion);
int eliminado= datos[posicion];

//eliminar posicion o correr.
    for(i=0;i<n;i++){
        if(i=posicion){
            datos[posicion]=0;
            while(i<n-1){
                datos[i]=datos[i+1];
                i=i+1;
            }
            break;
        }
    }
    n=n-1;
    //mostrando resultados
    printf("El array :\n");
    for(i=0;i<n;i++){
        printf("%5d",datos[i]);
    }
    printf("\n\n");
    printf("El elemento eliminado es:\n",eliminado);

    return 0;
}