#include <iostream>
#define filas 5
#define columnas 5
int main() {
    //variables
    int i, j;
    float cine[filas][columnas];
    int fila;
    float precio = 5;
    float precio2 = 3.5;
    float precio3 = 2.5;
    int opcion = 0;
    int ganancias=0;
    int lugar;
    do {
        printf("\n Menu: \n 1.Vender entradas. precios son: fila1:$5 fila5:$2.5 demas:$3.5 \n 2.Verificar. \n 3.mostrar ganancias. \n ");
        scanf("%i", &opcion);
        if (opcion < 1 && opcion > 3) {
        } else {
            if (opcion == 1) {
                printf("INgrese la fila en la que desea vender \n");
                scanf("%d",&fila);
                if (fila== 0) {
                    printf("que posicion de fila1: \n");
                    scanf("%d",&lugar);
                    for (i = 0; i <= fila; i = i++) {
                        for (j = 0; j < columnas; j++) {
                            cine[fila][columnas] = precio;
                        }
                    }
                    printf("Total:",precio);
                }
                if(fila> 0 && fila < 5) {
                    printf("que posicion desea: \n");
                    scanf("%d",&lugar);
                    for (i > 0; i < fila; i++) {
                        for (j = 0; j < columnas; j++) {
                            cine[fila][columnas] = precio2;
                        }
                    }
                    printf("Total:",precio2);
                }
                if (fila== 5) {
                    printf("que posicion de fila5: \n");
                    scanf("%d",&lugar);
                    for (i = fila; i <= fila; i = i++) {
                        for (j = 0; j < columnas; j++) {
                            cine[fila][columnas] = precio3;
                        }
                    }
                    printf("Total:",precio3);
                }

            } else {
                if (opcion == 2) {
                    for (i = filas; i <filas; i = i++) {
                        for (j = 0; j < columnas; j++) {
                            while(cine[i][j]!='0'){
                                printf("este asiento esta ocupado");
                            }
                            printf("este asiento no esta ocupado");
                        }
                        }
                }
                //suma ganancias en todas las filas y columnas
                if (opcion == 3) {
                    for (i = 0; i < filas;i++) {
                        for (j = 0; j < columnas; j++) {
                            ganancias += cine[filas][columnas] ;
                        }
                    }
                }
            }

        }
    }
        while (opcion <= 3);
    }




